import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.*;
public class LoginRegisterWindow {

    // Create a DatabaseConnection object
    private static DatabaseConnection dbConnection = new DatabaseConnection();

    public static void main(String[] args) {
        // Initialize the JFrame
        JFrame frame = new JFrame("Login/Register");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new BorderLayout());

        // Create a JPanel for role selection
        JPanel rolePanel = new JPanel();
        rolePanel.setLayout(new FlowLayout());

        // Create a JLabel for instructions
        JLabel roleLabel = new JLabel("Select your role:");

        // Create a JComboBox for role selection
        String[] roles = {"Admin", "Supplier", "Customer"};
        JComboBox<String> roleComboBox = new JComboBox<>(roles);

        // Add the roleLabel and roleComboBox to the panel
        rolePanel.add(roleLabel);
        rolePanel.add(roleComboBox);

        // Create a JPanel to hold the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        // Create the Login button
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedRole = (String) roleComboBox.getSelectedItem();
                String username = JOptionPane.showInputDialog(frame, "Enter your username:");
                String password = JOptionPane.showInputDialog(frame, "Enter your password:");

                // Authenticate the user
                if (dbConnection.authenticateUser(username, password)) {
                    JOptionPane.showMessageDialog(frame, "Login successful as " + selectedRole);
                    openDashboard(selectedRole); // Open the new frame after successful login
                } else {
                    JOptionPane.showMessageDialog(frame, "Login failed. Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Create the Register button
        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedRole = (String) roleComboBox.getSelectedItem();
                openRegistrationWindow(selectedRole); // Open the registration window
            }
        });

        // Add buttons to the panel
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);

        // Add the rolePanel and buttonPanel to the JFrame
        frame.add(rolePanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);

        // Make the frame visible
        frame.setVisible(true);
    }

    // Method to open a new registration window based on the selected role
    public static void openRegistrationWindow(String role) {
        // Create a new JFrame for registration
        JFrame registerFrame = new JFrame("Register as " + role);
        registerFrame.setSize(400, 250);
        registerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window

        // Create a JPanel for the registration form
        JPanel registerPanel = new JPanel();
        registerPanel.setLayout(new GridLayout(4, 2, 10, 10));

        // Create form labels and fields
        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(15);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(15);

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(15);

        // Create the Submit button
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword()); // Get password securely
                String email = emailField.getText();

                // Call the method to insert the user into the database
                insertUser(username, password, email, role);

                JOptionPane.showMessageDialog(registerFrame, "Registered as " + role +
                        "\nUsername: " + username + "\nEmail: " + email);
            }
        });

        // Add components to the registration panel
        registerPanel.add(usernameLabel);
        registerPanel.add(usernameField);
        registerPanel.add(passwordLabel);
        registerPanel.add(passwordField);
        registerPanel.add(emailLabel);
        registerPanel.add(emailField);
        registerPanel.add(new JLabel()); // Empty label for spacing
        registerPanel.add(submitButton);

        // Add the registration panel to the frame
        registerFrame.add(registerPanel);

        // Make the new registration frame visible
        registerFrame.setVisible(true);
    }

    // Method to insert a new user into the database using the DatabaseConnection class
    public static void insertUser(String username, String password, String email, String role) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            // Get a connection from the DatabaseConnection class
            conn = dbConnection.getConnection();

            // Insert user data into the 'users' table
            String insertSQL = "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(insertSQL);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, email);
            pstmt.setString(4, role);

            // Execute the insert statement
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("User registered successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Method to open a dashboard after successful login
    public static void openDashboard(String role) {
        // Create a new JFrame for the dashboard
        JFrame dashboardFrame = new JFrame("Dashboard - " + role);
        dashboardFrame.setSize(400, 300);
        dashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close the application when the dashboard is closed

        // Create a JPanel to hold the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(3, 2, 10, 10)); // 3 rows, 2 columns for 6 buttons

        // Create buttons for the dashboard
        JButton button1 = new JButton("Manage Products");
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ProductManagement(); // Open the product management frame
            }
        });

        JButton button2 = new JButton("Button 2");
        JButton button3 = new JButton("Button 3");
        JButton button4 = new JButton("Button 4");
        JButton button5 = new JButton("Button 5");

        // Add action listeners for other buttons (you can customize this)
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(dashboardFrame, "Button 2 clicked!");
            }
        });

        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(dashboardFrame, "Button 3 clicked!");
            }
        });

        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(dashboardFrame, "Button 4 clicked!");
            }
        });

        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(dashboardFrame, "Button 5 clicked!");
            }
        });

        // Add buttons to the panel
        buttonPanel.add(button1);
        buttonPanel.add(button2);
        buttonPanel.add(button3);
        buttonPanel.add(button4);
        buttonPanel.add(button5);

        // Add the button panel to the dashboard frame
        dashboardFrame.add(buttonPanel, BorderLayout.CENTER);

        // Make the dashboard frame visible
        dashboardFrame.setVisible(true);
    }
}
