import java.sql.*;

public class DatabaseConnection {
    private Connection connection;

    public DatabaseConnection() {
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            String url = "jdbc:mysql://localhost:3306/";
            String db = "miniproject"; // Your database name
            connection = DriverManager.getConnection(url + db, "root", "tanusri@15");
            System.out.println("Connected to the database.");

            // Call the method to create the users table
            createUsersTable();
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public Connection getConnection() {
        return connection;
    }

    // Close the database connection
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Disconnected from the database.");
            }
        } catch (SQLException e) {
            System.out.println("Failed to close the database connection: " + e.getMessage());
        }
    }

    // Method to create the 'users' table if it doesn't exist
    private void createUsersTable() {
        Statement stmt = null;
        try {
            stmt = connection.createStatement();

            // SQL statement to create the users table
            String createTableSQL = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "username VARCHAR(50) NOT NULL UNIQUE, " +
                    "password VARCHAR(255) NOT NULL, " + // Consider using a larger size for hashed passwords
                    "email VARCHAR(100) NOT NULL UNIQUE, " +
                    "role VARCHAR(20) NOT NULL)";

            // Execute the create table statement
            stmt.execute(createTableSQL);
            System.out.println("Table 'users' created or already exists.");
        } catch (SQLException e) {
            System.out.println("Failed to create the users table: " + e.getMessage());
        } finally {
            // Close the statement
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException ex) {
                System.out.println("Failed to close statement: " + ex.getMessage());
            }
        }
    }

    // Method to authenticate a user
    public boolean authenticateUser(String username, String password) {
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password); // Note: Hashing passwords is highly recommended in production

            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // Returns true if the user exists
        } catch (SQLException e) {
            System.out.println("Error during authentication: " + e.getMessage());
        }
        return false; // If something goes wrong or user not found
    }
}
